var animation = bodymovin.loadAnimation({
	
	container: document.getElementById('anima'),
	render: 'svg',
	loop: true,
	autoplay: true,
	path: 'DTO.json'
	
})

